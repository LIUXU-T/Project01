CREATE VIEW pub AS
  SELECT
    `test1`.`book`.`bookid`   AS `bookid`,
    `test1`.`book`.`bookname` AS `bookname`,
    `test1`.`book`.`pub`      AS `pub`,
    `test1`.`book`.`catalog`  AS `catalog`,
    `test1`.`book`.`price`    AS `price`
  FROM `test1`.`book`
  WHERE (`test1`.`book`.`pub` = '清华大学出版社');

